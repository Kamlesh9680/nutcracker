# Terabox Video Downloader Telegram Bot 🤖📹

This bot allows you to download files from Terabox and more through Telegram.

[Bot link](https://t.me/terabox_downloader_robot)

## Required environment variables
 `BOT_TOKEN` : Telegram Bot Token

 `WEBHOOK_URL` : Webhook URL of bot (your server url)...

Video Tutorial 
[Deploy on Heroku{paid}](https://youtu.be/KECEaNLRP2Q?si=4Ml3y_ikoxwT0qDG)

[Deploy On Render{Free}](https://youtu.be/Fs2jUph5VFE)


## Socials 
Join Our Telegram [Channel](https://telegram.dog/botcodes123)

If You Want Any Help Related To This Bot [Contact us On Telegram](https://telegram.dog/Armanidrisi_bot)